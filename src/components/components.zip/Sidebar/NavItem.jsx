"use client";
import React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ListItemButton, ListItemIcon, SvgIcon } from "@mui/material";
import { FaCircleNotch } from "react-icons/fa";

const NavItem = ({ path, icon, title }) => {
  const router = useRouter();
  const match = path?.split("/")[2] === router.pathname?.split("/")[2];

  return (
    <Link passHref href={path}>
      <ListItemButton
        sx={{
          color: "white",
          my: 2,
          py: 1.4,
          "&:hover": {
            bgcolor: "primary.dark",
          },
          "&.Mui-selected": {
            bgcolor: "white",
            color: "primary.main",
            "& .MuiListItemIcon-root": {
              color: "primary.main",
            },
            "&:hover": {
              bgcolor: "white",
            },
          },
        }}
        selected={Boolean(match)}
      >
        <ListItemIcon
          sx={{
            color: "white",
            fontSize: "1em",
            display:"flex",
            justifyContent:"center"
          }}
        >
          {icon || FaCircleNotch}
        </ListItemIcon>
        {title || ""}
      </ListItemButton>
    </Link>
  );
};

export default NavItem;
