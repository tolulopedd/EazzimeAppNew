"use client";
import React, { useState, useEffect } from "react";
import { GiHamburgerMenu } from "react-icons/gi";
import {
  Typography,
  IconButton,
  AppBar,
  Toolbar,
  Grid,
  Button,
  Box,
} from "@mui/material";
import { useNavToggle } from "@/hooks";
import EazziMeLogo from "@/assets/eazzime-logo.png";
import Image from "next/image";
import dayjs from "dayjs";
import { FaUser } from "react-icons/fa6";

const Navbar = ({ swipeable }) => {
  const { toggleSidebar } = useNavToggle();
  const [nowDate, setNowDate] = useState("");

  useEffect(() => {
    const todayDate = dayjs().format("dddd, MMMM, DD, YYYY hh:mm A");
    setNowDate(todayDate);
  }, []);

  return (
    <>
      <AppBar position="static" elevation={0}>
        <Toolbar variant="regular">
          <Grid
            container
            spacing={1}
            sx={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              textAlign: "center",
              flexWrap: "nowrap",
            }}
          >
            <Box>
              {swipeable && (
                <IconButton
                  onClick={toggleSidebar}
                  size={"large"}
                  edge="start"
                  color="inherit"
                  aria-label="menu"
                >
                  <GiHamburgerMenu color="#000" />
                </IconButton>
              )}
            </Box>
            <Grid item xs={2}>
              <Image
                src={EazziMeLogo}
                alt="logo"
                width={100}
                height={70}
                style={{
                  marginRight: "8rem",
                  display: "flex",
                  justifyContent: "flex-start",
                }}
              />
            </Grid>
            <Box
              sx={{
                width: "100%",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                textAlign: "center",
                marginTop: "16px",
              }}
            >
              <Grid
                item
                xs={5}
                sm={6}
                md={6}
                lg={6}
              >
                <Typography variant="body1">{nowDate}</Typography>
              </Grid>
              <Grid
                item
                xs={4}
                sm={6}
                md={6}
                lg={6}
                sx={{
                  width: "100%",
                  display: "flex",
                  justifyContent: "flex-end",
                }}
              >
                <Grid
                  sx={{
                    display: "flex",
                    alignItems: "center",
                  }}
                >
                  <FaUser color="#42E673" />
                  <Typography sx={{ color: "#000", margin: "0 0 0 0.5rem" }}>
                    Welcome Akpan Lauren
                  </Typography>
                </Grid>
                <Button
                  variant="contained"
                  onClick={() => {}}
                  sx={{
                    textTransform: "uppercase",
                    backgroundColor: "#0D2B36",
                    color: "#fff",
                    fontSize: "0.8em",
                    margin: "0 0 0 2rem",
                  }}
                >
                  Logout
                </Button>
              </Grid>
            </Box>
          </Grid>
        </Toolbar>
      </AppBar>
    </>
  );
};
export default Navbar;
